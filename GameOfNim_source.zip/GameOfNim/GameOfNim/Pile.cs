﻿/*
SIT215 - Artificial and Computational Intelligence
PBL Task 3: The Game of Nim
Leigh Rowell (ID: 219309149)
*/

using System;

namespace GameOfNim
{
    class Pile
    {
        /*
        This Class represents a pile of stones in the game of Nim. 
        */

        // Instance Variables
        private int _count;
        
        public int Count
        {
            get { return this._count; }
            set { this._count = value;  }
        }

        // Constructor
        public Pile()
        {
            // Default constructor - created with no stones.
            this.Count = 0;
        }
        public Pile(int numStones)
        {
            // overriding constructor to initialize with declared number of stones.
            this.Count = numStones;
        }
        public Pile(int numMin, int numMax)
        {
            // overriding constructor to initialize pile with random number of stones.
            Random rnd = new Random();
            this.Count = rnd.Next(numMin, numMax);
        }

        // Methods
        public bool RemoveStone(int stones)
        {
            // Removes the declared count from the stones count
            if (stones > this.Count) return false;
            this.Count -= stones;
            return true;
        }

        public void AddStone(int count)
        {
            // Adds count stone(s) to this..
            this.Count += count;
        }
        public void ClearPile()
        {
            this.Count = 0;
        }
    }
}
