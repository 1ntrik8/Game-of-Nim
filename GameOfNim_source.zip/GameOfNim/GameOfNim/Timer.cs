﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GameOfNim
{
    class Timer
    {
        private DateTimeOffset _startTime;
        private DateTimeOffset _endTime;
        private TimeSpan _elapsedTime;
        private bool running;

        public TimeSpan elapsedTime
        {
            get
            {
                return _elapsedTime;
            }
        }

        // Constructor
        public Timer()
        {
            _startTime = default;
            _endTime = default;
            running = false;
        }

        // Methods
        public void Start()
        {
            if(running == true)
            {
                Console.WriteLine("Timer is already running. Restarting...");
            }
            running = true;
            _startTime = DateTimeOffset.Now;
        }

        public void Stop()
        {
            running = false;
            _endTime = DateTimeOffset.Now;
        }

        public TimeSpan TimeValue()
        {
            _elapsedTime = _endTime.Subtract(_startTime);
            return elapsedTime;
        }
    }
}
