﻿/*
SIT215 - Artificial and Computational Intelligence
PBL Task 3: The Game of Nim
Leigh Rowell (ID: 219309149)
*/

using System;


namespace GameOfNim
{
    class Player_Human : Player
    {
        /*
        This class represents a Human player - the methods will ask the user for input to make the next move..
        */

        // Instance Variables:
        public string name;


        public Player_Human()
        {
            this.name = "Human Player";
        }

        public Player_Human(String name)
        {
            this.name = name;
        }

        public override void MakeMove(Board B)
        {
            int numPile = 0;
            int numStones = 0;

            if(B.Hints) Hint(B);

            do
            {
                try
                {
                    Console.Write("Enter the pile index to remove stones: ");
                    numPile = Int32.Parse(Console.ReadLine());
                    Console.Write("Enter the number of stones to remove: ");
                    numStones = Int32.Parse(Console.ReadLine());
                }
                catch
                {
                    numPile = -1;
                    numStones = 0;
                }

            } while (numPile < 0 || numPile > B.Piles.Count-1 || numStones < 1 || numStones > B.Piles[numPile].Count); // if player entered invalid move then keep asking until a valid move is entered.

            // valid entry - remove stones from pile.
            B.Move(numPile, numStones); //Piles[numPile].RemoveStone(numStones);

        }
        public void Hint(Board B)
        {
            (int,int) move = B.NimMove();
            int i = move.Item1;
            int j = move.Item2;

            Console.WriteLine("HINT: {0}, stones: {1}", i, j);

        }
        public override string ToString()
        {
            return this.name;
        }
    }
}
