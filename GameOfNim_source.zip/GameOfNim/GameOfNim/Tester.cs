﻿/*
SIT215 - Artificial and Computational Intelligence
PBL Task 3: The Game of Nim
Leigh Rowell (ID: 219309149)
*/

using System;

namespace GameOfNim
{
    class Tester
    {
        public static void RunTests()
        {
            TestPileClass();
            TestBoardClass();
            TestBoardInit();
            TestPlayer();
            TestBoardCopy();
            TestAI();
        }

        private static void TestPileClass()
        {
            // A simple method to create new Piles and output the count to console for debugging purposes...
            Console.WriteLine("Testing Piles Class");
            Pile P = new Pile(2, 10);
            Pile P2 = new Pile(5);
            Pile P3 = new Pile();
            Console.WriteLine("New pile P (random between 2 and 10) count is: {0}", P.Count);
            Console.WriteLine("New pile P2 (declared with 5 stones) count is: {0}", P2.Count);
            Console.WriteLine("New pile P3 (default zero stones) count is: {0}", P3.Count);
        }
        private static void TestBoardClass()
        {
            // A simple method to create a new board and test the methods for debugging purposes..
            Console.WriteLine("Testing the board class");
            Board B = new Board();
            B.AddPiles(new Pile(1, 10));
            B.AddPiles(new Pile(1, 10));
            B.AddPiles(new Pile(1, 10));
            B.AddPiles(new Pile(5));
            B.AddPiles(new Pile());

            Console.WriteLine("The board contains {0} piles...", B.GetPiles().Count);
            Console.WriteLine("Stones remaining in piles? {0}", B.StonesRemain());
            Console.WriteLine("GetPiles returns: {0}", B.GetPiles());

            B.DrawBoard();

            foreach (Pile P in B.GetPiles())
            {
                Console.WriteLine("Pile count: {0}", P.Count);
                P.ClearPile();
            }

            B.DrawBoard();
            Console.WriteLine("Stones remain now? {0}", B.StonesRemain());
        }
        private static void TestBoardInit()
        {
            int minP = 2;
            int maxP = 5;
            int minS = 2;
            int maxS = 5;

            Console.WriteLine("Testing board initialization...");
            Console.WriteLine("Piles: {0} to {1}. Stones: {2} to {3}.", minP, maxP, minS, maxS);
            Board B = new Board();
            B.Initialize(2, 5, 2, 5, false, false, true);
            B.DrawBoard();
            B.SwapPlayers();
            B.DrawBoard();
        }
        private static void TestPlayer()
        {
            Player P = new Player_Human("Leigh");
            Player P2 = new Player_Computer("My PC");
            P.Winner();
            P2.Winner();
            Player temp = P;
            temp.Winner();
            temp = P2;
            temp.Winner();
        }
        private static void TestBoardCopy()
        {
            Board B = new Board();
            B.Initialize(4, 8, 4, 8, false, true, true);
            B.DrawBoard();
            Board BTemp = B.Copy();
            BTemp.Move(0, 1);
            B.DrawBoard();
            BTemp.DrawBoard();
            Console.WriteLine("Board B Nimsum: {0}", B.NimSum());
            Console.WriteLine("Board BTemp Nimsum: {0}", BTemp.NimSum());
            B.OtherPlayer.MakeMove(B);
            B.DrawBoard();
        }
        private static void TestAI()
        {
            Board B = new Board();
            B.Initialize(4, 8, 4, 8, false, true, true);
            B.DrawBoard();
            Console.WriteLine("Board B Nimsum: {0}", B.NimSum());
            B.OtherPlayer.MakeMove(B);
            B.DrawBoard();
            Console.WriteLine("Board B Nimsum: {0}", B.NimSum());
        }
    }
}
