﻿/*
SIT215 - Artificial and Computational Intelligence
PBL Task 3: The Game of Nim
Leigh Rowell (ID: 219309149)
*/

using System;

namespace GameOfNim
{
    class Program
    {
        static void Main(string[] args)
        {
            //Tester.RunTests(); // Run tests for debugging purposes, test classes...

            int minP = 2;                   // minimum number of piles to create
            int maxP = 5;                   // maximum number of piles to create
            int minS = 2;                   // minimum number of stones in each pile
            int maxS = 5;                   // maximum number of stones in each pile
            bool Misere = true;            // Misere win condition true/false
            bool ComputerPlayer = true;     // Enable the computer player true/false
            bool Hints = false;              // Display hints for the player true/false


            // Start the game.
            // Keep starting a new game until the user closes the window..
            do
            {
                StartGame(minP, maxP, minS, maxS, Misere, ComputerPlayer, Hints); // StartGame(int minP, int maxP, int minS, int maxS, bool Misere, bool ComputerPlayer, bool Hints)
                Console.ReadKey();
                Console.Clear();
            } while(true);
            
        }

        private static void StartGame(int minP, int maxP, int minS, int maxS, bool Misere, bool ComputerPlayer, bool Hints)
        {
            // Create a board and start the game...
            Board B = new Board();
            B.Initialize(minP, maxP, minS, maxS, Misere, ComputerPlayer, Hints);
            B.Play();
        }


        public static void DrawLine()
        {
            // Draws a line across the console.. using method to keep all the lines the same.
            Console.WriteLine("=====================================================");
        }



    }
}
