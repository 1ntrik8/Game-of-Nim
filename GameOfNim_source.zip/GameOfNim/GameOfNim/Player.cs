﻿/*
SIT215 - Artificial and Computational Intelligence
PBL Task 3: The Game of Nim
Leigh Rowell (ID: 219309149)
*/

using System;


namespace GameOfNim
{
    class Player
    {
        /*
        Use generic player class so that the players can be swapped within the game...
        */

        // Instance Variables
        private string name;

        // Constructor

        // Methods
        public virtual void MakeMove(Board B) { }
        
        public void Winner()
        {
            Console.WriteLine("\n{0} is the Winner!\n", this.ToString());
            Program.DrawLine();
        }
    }
}
