﻿/*
SIT215 - Artificial and Computational Intelligence
PBL Task 3: The Game of Nim
Leigh Rowell (ID: 219309149)
*/

using System;


namespace GameOfNim
{
    class Player_Computer : Player
    {
        /*
        This class represents a Computer player - the methods will implement AI to decide on the best move to make and then execute it automatically..
        */

        // Instance Variables:
        public string name;

        public Player_Computer()
        {
            this.name = "Computer Player";
        }

        public Player_Computer(String name)
        {
            this.name = name;
        }

        public override void MakeMove(Board B)
        {
            


            (int, int) nimSumMove = B.NimMove();
            int nimSumPile = nimSumMove.Item1;
            int nimSumStones = nimSumMove.Item2;

            if (nimSumPile == -2)
            {
                // Nim sum already zero... remove a single stone from any pile.
                for (int i = 0; i < B.Piles.Count; i++)
                {
                    if (B.Piles[i].Count > 0)
                    {
                        Console.WriteLine("Move found! pile: {0}, stones: {1}", i, 1);
                        B.Move(i, 1);
                        return;
                    }
                }
            }
            else
            {
                // Execute the Nim Sum Zero or winning move..
                Console.WriteLine("Move Found! pile: {0}, stones: {1}", nimSumPile, nimSumStones);
                B.Move(nimSumPile, nimSumStones);
                return;
            }
        }

        public override string ToString()
        {
            return this.name;
        }
    }
}
