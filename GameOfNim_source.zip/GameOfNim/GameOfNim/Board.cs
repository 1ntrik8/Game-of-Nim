﻿/*
SIT215 - Artificial and Computational Intelligence
PBL Task 3: The Game of Nim
Leigh Rowell (ID: 219309149)
*/

using System;
using System.Collections.Generic;


namespace GameOfNim
{
    class Board
    {
        /*
        This class represents the board in the game of Nim
        */

        // Instance Variables
        private List<Pile> _piles = new List<Pile>();
        public Player CurrentPlayer = new Player();
        public Player OtherPlayer = new Player();
        public bool WinMisere = false;
        public bool Hints = true;
        public List<Pile> Piles
        {
            get
            {
                return this._piles;
            }
        }

        // Constructor
        public Board()
        {
            // Default constructor, no piles

        }

        // Methods
        public void Play()
        {
            // This is the main method of the game...
            while (StonesRemain())
            {
                DrawBoard();
                CurrentPlayer.MakeMove(this);
                SwapPlayers();
            }

            // No more stones, game has ended:
            DrawBoard();
            if (WinMisere) CurrentPlayer.Winner();
            if (!WinMisere) OtherPlayer.Winner();
        }

        public void Initialize(int minPiles, int maxPiles, int minStones, int maxStones, bool Misere, bool ComputerPlayer, bool Hints)
        {
            // This method initializes the board - creates Piles and adds players to the game.

            Random rnd = new Random();
            int numPiles = rnd.Next(minPiles, maxPiles);
            int numStones = 0;

            // Add Piles and Stones to the board.
            for (int i = 0; i < numPiles; i++)
            {
                numStones = rnd.Next(minStones, maxStones);
                _piles.Add(new Pile(numStones));
            }

            // Set players (make sure if nim-sum of the board is 0 then computer goes first!)
            CurrentPlayer = new Player_Human("Player 1");
            if (ComputerPlayer)
            {
                OtherPlayer = new Player_Computer();
                // If playing the computer and the initial nim-sum is zero then the computer goes first to give player a chance!
                if (this.NimSum() == 0) SwapPlayers();
            }
            else
            {
                OtherPlayer = new Player_Human("Player 2");
            }
            
            // Set win condition.
            this.WinMisere = Misere;

            // Set cheating condition
            this.Hints = Hints;

            Console.Clear();
            Console.WriteLine("Welcome to the Game of Nim!");
            Console.WriteLine("By Leigh Rowell - ID: 219309149");
            Console.WriteLine("SIT215 Deakin University T2 2020");
            Program.DrawLine();
            ShowRules();
            Program.DrawLine();
            Console.WriteLine("Piles: {0}", numPiles);
            Console.WriteLine("Stones: between {0} and {1}", minStones, maxStones);
            Console.WriteLine("Misere Rules: {0}", Misere);
            Console.WriteLine("Computer Player: {0}", ComputerPlayer);
            Console.WriteLine("Hints: {0}", Hints);
            Program.DrawLine();
            Console.WriteLine("Press a key to start!");
            Console.ReadKey();
            Console.Clear();
        }
        private void ShowRules()
        {
            Console.WriteLine("The Game of Nim");
            Console.WriteLine("Play starts with a series of piles, each containing at least one stone");
            Console.WriteLine("Players alternate turns removing at least one stone from a pile until");
            Console.WriteLine("a winning condition is met.");
            Console.WriteLine("Game Rules:");
            Console.WriteLine("1. You can remove any number of stones from a single pile");
            Console.WriteLine("2. You can only remove stones from a single pile during your turn");
            Console.WriteLine("3. You must remove at least one stone during your turn");
            Console.WriteLine("Misere win condition: Not being the last player to take stones from the board");
            Console.WriteLine("Normal win condition: Remove the last stones from the board");
        }
        public void Move(int pile, int stones)
        {
            //execute a move - remove stones from pile
            this._piles[pile].RemoveStone(stones);
        }
        public Board Copy()
        {
            Board RB = new Board();
            foreach (Pile P in this._piles)
            {
                RB.AddPiles(new Pile(P.Count));
            }
            RB.CurrentPlayer = this.CurrentPlayer;
            RB.OtherPlayer = this.OtherPlayer;
            RB.WinMisere = this.WinMisere;
            return RB;
        }
        public int NimSum()
        {
            // This method returns the nim-sum of the board passed in..
            int nimSum = 0;

            for (int i = 0; i < this.Piles.Count; i++)
            {
                nimSum ^= this.Piles[i].Count;
            }

            return nimSum;
        }
        public (int,int) NimMove()
        {
            // Find the best move from the current board state and return as the pile and stones...

            // Check if a winning move is possible, if so take it.
            // If the nim sum is already 0 then remove a single stone from any pile and wait for the player to make an error.
            // If the nim sum is not 0, carry out a DFS of moves until a nim-sum of zero is the result, and then execute this move.

            // Create timer to show how long it takes to find a move...
            Timer T = new Timer();
            T.Start();

            // If winning move can be taken then take it...
            // First get a list of all the stone counts, and keep track of the piles with stones in them..
            int pileIndex = 0;
            int pileCount = 0;
            int pilesWithStones = 0;
            int pilesWithManyStones = 0;
            int pilesManyIndex = 0;

            // Analyze board for winning move.. get indexes for last pile and piles with many stones, as well as the counts of the piles.
            for (int i = 0; i < this._piles.Count; i++)
            {
                if (this._piles[i].Count > 0)
                {
                    pilesWithStones++;
                    pileIndex = i;
                    pileCount += this._piles[i].Count;
                    if (this._piles[i].Count > 1)
                    {
                        pilesWithManyStones++;
                        pilesManyIndex = i;
                    }
                }
            }

            // If there is one pile left... make the final move...
            if (pilesWithStones == 1)
            {
                if (this.WinMisere && pileCount > 1)
                {
                    ShowTime(T);
                    return (pileIndex, pileCount - 1);
                }
                else
                {
                    ShowTime(T); 
                    return (pileIndex, pileCount);
                }
            }

            // Misere Strategy:
            // If there is only one pile with more than one stone, remove stones from this pile to leave an odd number of single stone piles.
            // If playing Misere, this is the winning move so return it.
            if (this.WinMisere && pilesWithManyStones == 1)
            {
                if (pilesWithStones % 2 == 0) return (pilesManyIndex, _piles[pilesManyIndex].Count);
                ShowTime(T);
                return (pilesManyIndex, _piles[pilesManyIndex].Count - 1);
            }

            // The following algorithm finds the move which results in a board with nim-sum of zero
            if (this.NimSum() == 0) return (-2, -2); // if no move is available return this.

            Board BCopy = this.Copy(); // Make a copy of the board so we can execute test moves on it...

            for (int i = 0; i < this.Piles.Count; i++)
            {
                for (int j = 1; j < this.Piles[i].Count + 1; j++)
                {
                    BCopy.Move(i, j); // Remove a single stone from the pile until a move is found.
                    // Debug lines..
                    //Console.WriteLine("i: {0}, j: {1}", i, j);
                    //Console.WriteLine("nimsum: {0}", BCopy.NimSum()) ;
                    if (BCopy.NimSum() == 0)
                    {
                        // A nim-sum zero move found.. return the pile and stones values.
                        ShowTime(T); 
                        return (i,j);
                    }
                    BCopy = this.Copy(); // if no move found in current board, reset the copy to the current board and move to the next pile..
                }
                BCopy = this.Copy(); // if no move found in current board, reset the copy to the current board and move to the next pile..
            }
            Console.WriteLine("AI Broke, can't find a move!");
            ShowTime(T); 
            return (-1, -1); // default return value of no move is found.
        }
        private void ShowTime(Timer T)
        {
            T.Stop();
            Console.WriteLine("Time Taken to find move: {0}", T.TimeValue());
        }
        public bool StonesRemain()
        {
            // Check all of the piles, if any have a count greater than 0 then return true, otherwise return false.
            foreach (Pile P in Piles)
            {
                if (P.Count > 0) return true;
            }
            return false;
        }
        public List<int> PilesWithStones()
        {
            // Return list of integers containing the count for each pile
            List<int> numPiles = new List<int>();
            foreach(Pile P in _piles)
            {
                if (P.Count > 0) numPiles.Add(P.Count);
            }
            return numPiles;
        }
        public List<Pile> GetPiles()
        {
            // return the Piles list from the board
            return this.Piles;
        }
        public void AddPiles (Pile P)
        {
            // adds the passed Pile to the board
            this._piles.Add(P);
        }
        public void RemovePile (int index)
        {
            // removes pile at passed index.
            if (index < 0 || index > _piles.Count - 1) throw new IndexOutOfRangeException("Pile does not exist at that index");
            _piles.RemoveAt(index);
        }
        public void ClearBoard()
        {
            // Removes all piles from the board
            _piles.Clear();
        }
        public void SwapPlayers()
        {
            // Swaps current and other player..
            Player Temp = CurrentPlayer;
            this.CurrentPlayer = OtherPlayer;
            this.OtherPlayer = Temp;
        }
        public void DrawBoard()
        {
            // Draws the current board state on the console..
            Program.DrawLine();
            Console.WriteLine("Current player: {0}", CurrentPlayer.ToString());
            for (int i = 0; i < this.Piles.Count; i++)
            {
                Console.Write("Pile {0}({1}):\t", i, Piles[i].Count);
                for (int j = 0; j < this.Piles[i].Count; j++)
                {
                    Console.Write("#");
                }
                Console.WriteLine();
            }
            Program.DrawLine();
        }
        
    }
}
